package com.FK.game;

public enum JumpState { NONE, PASS, JUMPING, FALLING };